from django.apps import AppConfig


class AppTksConfig(AppConfig):
    name = 'app_tks'
